import { BrowserRouter, Routes, Route } from 'react-router-dom'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<div>서비스 소개</div>} />
        <Route path="/download" element={<div>앱 다운로드</div>} />
        <Route path="/features" element={<div>기능 소개</div>} />
        <Route path="*" element={<div>404</div>} />
      </Routes>
    </BrowserRouter>
  )
}

export default App