export interface Account {
  accountId: number
  bankCode: string
  bankName: string
  accountNumber: string
  accountName: string
  balance: number
  status: string
  createdAt: string
  closedAt?: string
}
