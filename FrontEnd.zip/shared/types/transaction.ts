export interface Transaction {
  transactionId: number
  accountId: number
  userId: number
  direction: 'IN' | 'OUT'
  amount: number
  balanceAfter: number
  merchantName: string
  memo?: string
  createdAt: string
  transactionAt: string
  categoryId: number
}

export interface TransactionMemoRequest {
  memo: string
}
