export interface User {
  id: number
  loginId: string
  userName: string
  gender: 'M' | 'F'
  birthDate: string
  phoneNumber: string
  jobId: number
  createdAt: string
  updatedAt: string
}

export interface UserUpdateRequest {
  userName?: string
  phoneNumber?: string
  jobId?: number
}

export interface NotificationSetting {
  notificationTypesId: number
  enabled: boolean
  updatedAt: string
}
