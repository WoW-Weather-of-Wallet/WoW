export interface SpendingType {
  typeId: number
  typeName: string
  icon: string
  description: string
}

export interface SpendingTypeAnalysis {
  spendingType: SpendingType
  categoryBreakdown: {
    categoryId: number
    categoryName: string
    percentage: number
  }[]
  reasons: {
    order: number
    icon: string
    title: string
    content: string
  }[]
  aiComment: string
}

export interface WeeklyForecast {
  date: string
  dayOfWeek: string
  riskLevel: 'SAFE' | 'WARNING' | 'DANGER'
  reason?: string
}

export interface MonthlyCompare {
  currentMonth: {
    yearMonth: string
    totalAmount: number
    categories: { categoryId: number; categoryName: string; percentage: number }[]
  }
  lastMonth: {
    yearMonth: string
    totalAmount: number
    categories: { categoryId: number; categoryName: string; percentage: number }[]
  }
  aiComment: string
}

export interface BudgetInfo {
  goalAmount: number
  spentAmount: number
  remainingAmount: number
  remainingDays: number
  dailyAvailable: number
  estimatedSaving: number
}
