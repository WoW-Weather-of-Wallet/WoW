import { Transaction } from './transaction'

export type DayType = 'PAST' | 'TODAY' | 'NEAR_FUTURE' | 'FAR_FUTURE'

export interface CalendarDay {
  calendarGoalId: number
  userId: number
  date: string
  dayType: DayType
  dailyTotal: number
  isForecast: boolean
  spendingWeatherId?: number
}

export interface CalendarHeader {
  userName: string
  currentBalance: number
  monthlyGoal: number
  currentMonthSpent: number
  remainingBudget: number
  weatherDescription: string
}

export interface DailySummary {
  summaryId: number
  date: string
  totalExpense: number
  transactionCount: number
  transactions: Transaction[]
  memo?: string
}

export interface FixedExpense {
  id: number
  accountId: number
  categoryId: number
  userId: number
  icon: string
  name: string
  amount: number
  dueDay: number
  isAuto: boolean
  isEnable: boolean
  paymentStatus: string
  sourceTxnName?: string
}
