import axios from 'axios'
import { BASE_URL } from './endpoints'

const axiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// 요청 인터셉터 - accessToken 자동 주입
axiosInstance.interceptors.request.use(
  (config) => {
    // 웹: localStorage / 앱: AsyncStorage에서 각자 토큰 주입
    // shared에서는 토큰 주입 로직을 외부에서 설정하도록 함
    return config
  },
  (error) => Promise.reject(error)
)

// 응답 인터셉터 - 401 시 토큰 갱신
axiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // 토큰 갱신 로직은 각 플랫폼에서 처리
    }
    return Promise.reject(error)
  }
)

export default axiosInstance
