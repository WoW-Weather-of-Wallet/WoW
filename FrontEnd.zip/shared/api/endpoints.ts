export const BASE_URL = 'http://localhost:8080'

export const ENDPOINTS = {
  // 사용자 관리
  AUTH: {
    SIGNUP: '/api/v1/auth/signup',
    LOGIN: '/api/v1/auth/login',
    LOGOUT: '/api/v1/auth/logout',
    REFRESH: '/api/v1/auth/refresh',
    PHONE_SEND: '/api/v1/auth/phone/send',
    PHONE_VERIFY: '/api/v1/auth/phone/verify',
    CHECK_EMAIL: '/api/v1/auth/check-email',
    EMAIL_VERIFY_REQUEST: '/api/v1/auth/email-verifications',
    EMAIL_VERIFY_CONFIRM: '/api/v1/auth/email-verifications/confirm',
    GOOGLE_OAUTH: '/oauth2/authorization/google',
  },
  USER: {
    ME: '/api/v1/users/me',
    PASSWORD: '/api/v1/users/me/password',
    NOTIFICATIONS: '/api/v1/users/me/notifications',
    ONBOARDING: '/api/v1/users/me/onboarding',
  },
  TERMS: {
    LIST: '/api/v1/terms',
    AGREE: '/api/v1/terms/agree',
  },

  // 계좌
  ACCOUNTS: {
    LIST: '/api/v1/accounts',
    BALANCE: (accountId: number) => `/api/v1/accounts/${accountId}/balance`,
    TRANSACTIONS: (accountId: number) => `/api/v1/accounts/${accountId}/transactions`,
  },
  TRANSACTIONS: {
    MEMO: (transactionId: number) => `/api/v1/transactions/${transactionId}/memo`,
  },

  // 캘린더
  CALENDAR: {
    HEADER: '/api/v1/calendar/header',
    MONTHLY: '/api/v1/calendar/monthly',
    FIXED_EXPENSES: '/api/v1/calendar/fixed-expenses',
    TRANSACTIONS: '/api/v1/calendar/transactions',
    AI_FEEDBACK: '/api/v1/calendar/aifeedback',
  },

  // 지출
  FIXED_EXPENSES: {
    LIST: '/api/v1/fixed-expenses',
    BY_CATEGORY: (category: string) => `/api/v1/fixed-expenses?category=${category}`,
    DETAIL: (id: number) => `/api/v1/fixed-expenses/${id}`,
  },
  EXPENSES: {
    LIST: '/api/v1/expenses',
    DETAIL: (id: number) => `/api/v1/expenses/${id}`,
  },

  // 메인
  MAIN: {
    SPENDING_TYPE: '/api/v1/main/spending-type',
    SPENDING_TYPE_ANALYSIS: '/api/v1/main/spending-type/analysis',
    SPENDING_MONTHLY: '/api/v1/main/spending/monthly',
    BUDGET: '/api/v1/main/budget',
    WEEKLY_FORECAST: '/api/v1/main/calendar/weekly-forecast',
    MONTHLY_COMPARE: '/api/v1/main/spending/monthly/compare',
  },

  // 가이드
  GUIDE: '/api/v1/guide',
} as const
